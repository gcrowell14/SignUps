//
//  SignUpsApp.swift
//  SignUps
//
//  Created by Grace Crowell on 4/15/23.
//

import SwiftUI

@main
struct SignUpsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
